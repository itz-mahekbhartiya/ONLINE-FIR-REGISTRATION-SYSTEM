<div class="footer">
            <div class="container">
                <div class="footer-top">
                    <h2 style="color: white">Quick Links</h2>
                     <br />
                   
                                            
                        <li><a href="index.php"><strong style="color: white">
                        Home</strong></a></li>
                        <li><a href="admin/signin.php"><strong style="color: white">Admin</strong></a></li>
                        <li><a href="police/signin.php"><strong style="color: white">Police</strong></a></li>
                        <li><a href="user/signin.php"><strong style="color: white">User</strong></a></li>
                       
                 
                     <p class="footer-class"> © 2020 Crime Record Management System </p>
                    <ul class="social">
                        <li><a href="#"><i> </i></a></li>                       
                        <li><a href="#"><i class="rss"> </i></a></li>
                        <li><a href="#"><i class="twitter"> </i></a></li>
                        <li><a href="#"><i class="dribble"> </i></a></li>
                        <li><a href="#"><i class="linked"> </i></a></li>
                        <li><a href="#"><i class="camera"> </i></a></li>
                    </ul>
                </div>
            </div>
        </div>