
<!DOCTYPE html>
<html>
<head>
<title>Crime Record Management System | Home</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</head>
<body>
<div class="header">
	
</div>
<?php include_once('includes/header.php');?>

<!--content-->
	<div class="content">
		<div class="container">
			
			<div class="content-welcome">
			
				<div class="col-md-8 come">
					<div class=" welcome">
						<a href="index.php"><img src="images/unnamed.png" alt=""></a>
					</div>
				</div>
				<div class="col-md-4 red">
				<h3>Mission & Vision</h3>
				<ul>
							<li>The unified mission of the Police Families Welfare Association, as obvious, is the WELFARE of POLICE FAMILIES. Every effort of PFWS team members is directed towards the welfare of the police community.</li>
							<li>To add specificity to our mission, we have directed our focus towards the specific aspects of welfare.</li>
							<li>The focus areas specified include economic & financial betterment, education & skill development and health & Welbeing.</li>
							<li>To effectively support the families of Police staff economically, emotionally and extend the successful programs to general public wherever feasible.</li>
							<li>Our vision is to work for an equitable society and for holistic development of families of Police staff.</li>
							<li></li>
							<li></li>
						
							
						</ul>
				</div>
				<div class="clearfix"> </div>
		
			</div>
			<!---->
		
			<!---->
		</div>
		
		<!--footer-->
		<?php include_once('includes/footer.php');?>
		<!--//footer-->
</body>
</html>